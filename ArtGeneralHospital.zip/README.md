#  Art General Hospital

A comprehensive healthcare management website featuring user dashboards, appointment scheduling, and services for hospital administration.

## Features
- Appointment Scheduling
- Patient, Doctor, and Admin Dashboards
- Lab Requests and Pharmacy Services

## Installation
1. Import `database/form.sql` into your database.
2. Set up server configurations.

## Technologies Used
- HTML, CSS, JavaScript
- PHP for backend
- MySQL Database
