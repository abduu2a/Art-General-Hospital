
    document.querySelector('.menu-icon').addEventListener('click', () => {
        document.querySelector('.menu').classList.toggle('active');
    });
   